/** @type {import('tailwindcss').Config} */
module.exports = {
  // Указываем все файлы, в которых используются классы Tailwind
  content: [
    "./**/*.html",
    "./src/**/*.js",
  ],
  theme: {
    extend: {
      // Кастомные настройки для дизайна
      colors: {
        'primary-blue': '#1e3a8a',
        'secondary-yellow': '#fde047',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins:,
}