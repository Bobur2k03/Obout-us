document.addEventListener('DOMContentLoaded', () => {

    // ==========================================================
    // 1. ЛОГИКА ВАЛИДАЦИИ КОНТАКТНОЙ ФОРМЫ (contact.html)
    // Активация кнопки "Отправить" только при заполнении всех 3 полей.
    // ==========================================================
    
    const requiredInputs = document.querySelectorAll('.required');
    const submitButton = document.getElementById('submitBtn');

    /**
     * Проверяет, заполнены ли все обязательные поля с классом 'required'.
     */
    function checkInputs() {
        if (!submitButton) return; // Проверка, что мы на странице с формой

        let isValid = true;
        
        requiredInputs.forEach(input => {
            // Проверяем, что поле не пустое после удаления пробелов
            if (input.value.trim() === "") {
                isValid = false;
            }
        });
        
        // Устанавливаем состояние 'disabled'
        submitButton.disabled =!isValid; 
        
        // Визуальное обновление кнопки с помощью классов Tailwind
        if (isValid) {
            submitButton.classList.remove('opacity-50', 'cursor-not-allowed');
            submitButton.classList.add('hover:bg-primary-blue/80');
        } else {
            submitButton.classList.add('opacity-50', 'cursor-not-allowed');
            submitButton.classList.remove('hover:bg-primary-blue/80');
        }
    }

    // Добавляем слушатель событий 'input' на каждое обязательное поле.
    // Это запускает проверку при любом изменении текста (ввод, вставка и т.д.)
    requiredInputs.forEach(input => {
        input.addEventListener('input', checkInputs);
    });

    // Вызываем проверку при загрузке страницы, чтобы учесть автозаполнение браузером
    if (requiredInputs.length > 0) {
        checkInputs();
    }


    // ==========================================================
    // 2. ЛОГИКА АНИМАЦИИ ПЕРСОНАЖА (GSAP ScrollTrigger)
    // ==========================================================

    const minion = document.querySelector(".minion-character");
    const fallingTrigger = document.getElementById('falling-trigger');

    if (minion && window.innerWidth >= 768) { // Активируем анимацию только на десктопе

        gsap.registerPlugin(ScrollTrigger);

        // Анимация Входа (Появление из угла при загрузке)
        gsap.from(".minion-container", {
            duration: 1.5,
            x: 100, // Сдвигаем влево (за пределы экрана)
            y: -100, // Сдвигаем вверх (за пределы экрана)
            rotation: 90,
            ease: "power2.out"
        });

        // Анимация Падения (Триггер в конце страницы)
        if (fallingTrigger) {
            
            // Создаем Timeline, привязанный к прокрутке
            let fallingTL = gsap.timeline({
                scrollTrigger: {
                    trigger: fallingTrigger, // Элемент перед футером
                    start: "top bottom", // Анимация начинается, когда верх триггера касается низа вьюпорта
                    end: "+=1500", // Анимация длится 1500px прокрутки
                    scrub: 1, // Плавное "скраббирование" (привязка к скроллу)
                    // markers: true, // Раскомментируйте для отладки
                }
            });
            
            // Определяем фазы падения
            fallingTL.to(minion, {
                y: "300vh", // Перемещаем далеко вниз
                x: 100, // Небольшой сдвиг по горизонтали для эффекта полета
                rotation: 1080, // 3 полных оборота
                scale: 0.1, // Уменьшение размера, чтобы создать ощущение удаленности
                ease: "power1.in", // Ускоряющееся падение
                duration: 2, 
            });
        }
    }
});